import * as fabric from 'fabric';
console.log('Type of fabric:', typeof fabric);
console.log('Keys of fabric:', Object.keys(fabric));
